// less 主题
export const theme = {
    '@primary-color': '#ffab00',
    '@border-radius-base': '0',
    '@border-radius-sm': '0'
}
