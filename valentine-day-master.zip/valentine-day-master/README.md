# 情人节土味情话大集合，程序员表白神器！

## 扫描二维码看效果

![avatar](/src/assets/images/qrcode.jpg)

### npm i 安装依赖

### npm start 启动服务

### localhost:4000
